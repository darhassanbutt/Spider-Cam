let spidercam;
let x;
let y;
let a;
let b;
let inc1;
let inc2;



function setup(){
 createCanvas(800,800);
 angleMode(DEGREES);
  x=-200;
  y=50;
  r = 0;
  s1 = 1;
  s2 = 1;
  spidercam=loadImage('cam.png');
  back = loadImage('back.png');
 }
 function drone(img_d ,xd,yd,rd,a,b){
	push();
	translate(xd,yd);
	rotate(rd);
	imageMode(CENTER);
	scale(a,b)
	translate(-xd,-yd);
	image(img_d ,xd,yd,width/10,height/10);
	pop();
 }


 function draw(){
    clear();
    background('#ABCD12');
    image(back,0,0,width,height);
    translate(width/2,height/2);


	drone(spidercam,x,y,r,s1,s2);
	if (keyCode === 38){
	    if (y>-210) {
            y -= 5;
			text("position on y",0,-5)
			
			
			
        }
    }
	if (keyCode === 40){
	    if (y<50)
	        y+=5;
    }

	if (keyCode === 39){
        if (x<150){
            x+=10;
			s1 = -1;
			s2 = 1;
			

        }
    }
	if (keyCode === 37){
	    if (x>-210){
	        x-=10;
			r = 0;
			s1 = 1;
			s2 = 1;
        }
    }
    if (key === 'w'){
        if (y>-210 && x<150 ){
            y -=10;
            x+=14;
			s1 = -1;
			s2 =1;
        }
    }
    if (key === 's'){
        if (y<50 && x>-210 ){
            y +=10;
            x-=14;
			s1=1;
			s2=1;
        }
    }
    if (key === 'a'){
        if (y<50 && x<150){
            x +=13;
            y +=10;
			s1 = -1;
			s2 =1;
            
        }
    }
	
     if (key === 'd'){
        if (y>-210 && x>-200){
            x -=13;
            y -=10;
			s1=1;
			s2=1;
           
        }
    }
		
 }
 
 